%Ilham Nur Romdoni, M0520038

% Looping for kondisi 1
for i = 1:5
    p = i^2
end

% Looping for kondisi 2
for j = 1:0.5:5
    q = j/2
end