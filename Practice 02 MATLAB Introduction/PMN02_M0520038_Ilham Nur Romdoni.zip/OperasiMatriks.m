%Ilham Nur Romdoni, M0520038

x = [4 5 6; 6 7 8; 8 9 0];
y = [1 2 3; 6 5 4; 7 9 1];
z = x*y
a = x.*y
b = x.^y
c = det(x)
d = inv(y)
