%Ilham Nur Romdoni, M0520038

x = input('Masukan angka : ');
fprintf('Anda telah menginput angka ');
disp(x);