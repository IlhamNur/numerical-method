%Ilham Nur Romdoni, M0520038

p = 0;
while(p <= 10)
    q = p^2 + p
    p = p + 1;
end
