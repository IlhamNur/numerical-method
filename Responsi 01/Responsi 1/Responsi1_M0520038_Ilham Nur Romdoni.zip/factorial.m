% Ilham Nur Romdoni, M0520038

function f = factorial(m)
f = 1;
for i = m:-1:1
    f = f*i;
end

