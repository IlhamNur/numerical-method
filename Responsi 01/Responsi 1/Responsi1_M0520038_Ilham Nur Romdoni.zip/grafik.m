% Ilham Nur Romdoni, M0520038

t = 0:0.01:5;
y1 = 4*(cos((48/16)*t)+exp(10));
y2 = 4*(cosine((48/16)*t,24)+exponent(10,24));
y3 = 4*(cosine((48/16)*t,25)+exponent(10,25));
y4 = 4*(cosine((48/16)*t,26)+exponent(10,26));
plot(t,y1,'r',t,y2,'b',t,y3,'y',t,y4,'g');