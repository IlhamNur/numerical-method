%Fawwaz Ivandra - M0520030 
function m = RegulasiFalsi(f,a,b,n,j)
format long
fa = f(a);
fb = f(b);
if (fa*fb > 0.0)
    error('tidak ada nilai akar')
end
fprintf('Iter\ta\t\t\tb\t\t\tm\t\t  fa\t\tfb\t\t\tabs(y)\n');
for i = 1:n
    m = (fb*a - fa*b)/(fb-fa);
    y = f(m);
    fprintf('%3.0f %10.6f %10.6f', i,a,b);
    fprintf('%10.6f %10.6f %10.6f %12.3e\n', m,fa,fb,abs(y));
    if (abs(y) <= j)
        break;
    end
    if (fa*y < 0)
        b = m;
    else
        a = m;
    end
end

