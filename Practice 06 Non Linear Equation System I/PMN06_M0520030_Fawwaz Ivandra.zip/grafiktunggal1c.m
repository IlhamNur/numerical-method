%Fawwaz Ivandra - M0520030
x = -0.3:0.001:1.2;
f = -2*x.^6 - 1.6*x.^4 + 12*x + 1;
X = -1:0.1:1.2;
Y = 2*ones(size(X));
Y1 = -6:1:12;
X1 = 0.*Y1;
plot(X,Y,'r', X1,Y1,'r',x,f,'b');
gtext('y = -2x^6 - 1.6x^4 + 12x + 1');
gtext('akar');
