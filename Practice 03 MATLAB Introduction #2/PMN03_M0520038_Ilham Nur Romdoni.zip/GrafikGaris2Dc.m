%Ilham Nur Romdoni, M0520038

x = linspace(0,20);
y = exp(-x/4).*sin(x);
plot(x,y);
xlabel('sumbu x');
ylabel('Sumbu y');
title('Gambar grafik persamaan f(x) = exp(-x/4).*sin(x)');