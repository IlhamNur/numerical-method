%Ilham Nur Romdoni, M0520038

x = 0:10:100;
y = x.^3 + 2*x.^2 - 40*x;
plot(x,y);