%Ilham Nur Romdoni, M0520038

f = input ('Fungsi : ');
f_asli = sym(f)
f_integral = int(f_asli, 'x')