%Ilham Nur Romdoni, M0520038 //comment
x = 20
y = 5
z = x + y

